function gerarPiramide() {
    var num = parseInt(document.getElementById('piramid').value);
    var resultado = '';

    for (var i = 1; i <= num; i++) {
        for (var j = 1; j <= i; j++) {
            var numeroFormatado = i.toString().padStart(2, '0');
            resultado += numeroFormatado + ' ';
        }
        resultado += '\n';
    }

    alert(resultado);
}