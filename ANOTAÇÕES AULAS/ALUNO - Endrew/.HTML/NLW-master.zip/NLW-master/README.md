# NLW eSports

| *Tilha explorer* - [🔗 Page Here](https://endrewsk.github.io/NLW/) |
<br><br>
**Projeto construído no evento Next Level Week da `Rocketseat`**

## 🛠 Tecnologias
- HTML
- CSS
- Git e github

![preview](./.github/Preview.png)

### Entre em Contato

[E-mail](mailto:s.endrew.oliveira@gmail.com?subject=Dev)

[Whatsapp](https://api.whatsapp.com/send/?phone=5519984176804&text=Eai,+beleza?&type=custom_url&app_absent=0)